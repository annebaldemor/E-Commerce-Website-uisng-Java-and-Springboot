package com.middle.app.midrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MidrestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MidrestApiApplication.class, args);
	}

}
