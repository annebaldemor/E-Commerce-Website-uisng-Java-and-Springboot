package com.middle.app.midrest.Controller;

import com.middle.app.midrest.Models.Item;
import com.middle.app.midrest.Repo.ItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;


import java.util.List;

@RestController
public class ApiControllers {

    @Autowired
    private ItemRepo itemRepo;


    @GetMapping(value = "/")
    public String getPage() {
        return "Welcome";
    }

    @GetMapping(value = "/items")
    public List<Item> getItems() {
        return itemRepo.findAll();
    }

    @PostMapping(value = "/save")
    public String saveItems(@RequestBody Item item){
        itemRepo.save(item);
        return "Saved...";
    }

    @PutMapping(value = "update/{id}")
    public String updateItem(@PathVariable long id,  @RequestBody Item item){
        Item updatedItem = itemRepo.findById(id).get();
        updatedItem.setItemName(item.getItemName());
        updatedItem.setItemDescription(item.getItemDescription());
        updatedItem.setItemQuantity(item.getItemQuantity());
        updatedItem.setItemPrice(item.getItemPrice());
        itemRepo.save(updatedItem);
        return "Updated...";
    }

    @DeleteMapping(value = "/delete/{id}")
    public String deleteItem(@PathVariable long id){
        Item deleteItem = itemRepo.findById(id).get();
        itemRepo.delete(deleteItem);
        return "Delete item with the id: "+ id;
    }
}


